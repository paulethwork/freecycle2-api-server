package hello;

public class RecyclingCenter {
    private final long id;
    private final String content;
    private final String payment;

    public RecyclingCenter(long id, String content, String payment) {
        this.id = id;
        this.content = content;
        this.payment = payment;
    }

    public long getId() {
        return id;
    }

    public String getContent() {
        return content;
    }

    public String getPayment() {
        return payment;
    }
}
