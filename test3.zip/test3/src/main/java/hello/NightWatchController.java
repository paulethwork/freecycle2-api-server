package hello;

import java.util.concurrent.atomic.AtomicLong;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class NightWatchController {

    private static final String template = "Welcome to the neighbourhood night watch, %s!\n " +
            "You've been paid %s ethers to your Ethereum wallet";
    private final AtomicLong counter = new AtomicLong();

    @RequestMapping("/nightwatch")
    public Greeting greeting(@RequestParam(value="name", defaultValue="World") String name,
                             @RequestParam(value="payment", defaultValue="0.1") String payment) {
        return new Greeting(counter.incrementAndGet(),
                String.format(template, name, payment));
    }
}